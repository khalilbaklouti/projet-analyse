﻿namespace MeetingScheduler
{
    internal class selectedEmployees
    {
        public static object Items { get; internal set; }
    }
}