﻿namespace MeetingScheduler
{
    internal class detailsTime
    {
        internal static string Text;
    }
}