﻿namespace MeetingScheduler
{
    internal class detailsTitle
    {
        public static string Text { get; internal set; }
    }
}