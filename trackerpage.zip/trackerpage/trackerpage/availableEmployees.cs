﻿
namespace MeetingScheduler
{
    internal class availableEmployees
    {
        public static object Items.Add { get; internal set; }
        public static required IEnumerable<object> SelectedItems { get; internal set; }

        
    }
}