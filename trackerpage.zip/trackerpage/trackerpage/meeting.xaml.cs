﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace ScheduleApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<ScheduleEntry> ScheduleEntries { get; } = new ObservableCollection<ScheduleEntry>();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // This is the 'Add Availability' button logic
            string employeeName = employeeNameTextBox.Text;
            string selectedDay = ((ComboBoxItem)dayComboBox.SelectedItem)?.Content?.ToString();
            string startTime = startTimeTextBox.Text;
            string endTime = endTimeTextBox.Text;

            if (string.IsNullOrEmpty(employeeName) || selectedDay == null || string.IsNullOrEmpty(startTime) || string.IsNullOrEmpty(endTime))
            {
                MessageBox.Show("Please fill all fields properly.");
                return;
            }

            // Add the availability
            ScheduleEntries.Add(new ScheduleEntry
            {
                Name = employeeName,
                Day = selectedDay,
                StartTime = startTime,
                EndTime = endTime,
                IsAvailable = true // Assume availability when adding
            });

            ClearFormInputs();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // This is the 'Not Available' button logic
            if (dataGrid.SelectedItem is ScheduleEntry selectedEntry)
            {
                selectedEntry.IsAvailable = false; // Mark as not available
                dataGrid.Items.Refresh(); // Refresh to reflect changes in UI if necessary
            }
        }

        private void ClearFormInputs()
        {
            employeeNameTextBox.Clear();
            dayComboBox.SelectedIndex = -1;
            startTimeTextBox.Clear();
            endTimeTextBox.Clear();
        }

        public class ScheduleEntry
        {
            public string Name { get; set; }
            public string Day { get; set; }
            public string StartTime { get; set; }
            public string EndTime { get; set; }
            public bool IsAvailable { get; set; }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
{
    // Logic to open the Add Employee window
    var addEmployeeWindow = new ScheduleApp.MainWindow();
    addEmployeeWindow.Show();
}

private void Button_Click_3(object sender, RoutedEventArgs e)
{
    // Logic to open the Schedule Meeting window
    var scheduleMeetingWindow = new MeetingScheduler.MainWindow();
    scheduleMeetingWindow.Show();
}

private void Button_Click_4(object sender, RoutedEventArgs e)
{
  
    
}

    }
}
