﻿
namespace MeetingScheduler
{
    internal class meetingTime
    {
        internal static ReadOnlySpan<char> Text;
    }
}