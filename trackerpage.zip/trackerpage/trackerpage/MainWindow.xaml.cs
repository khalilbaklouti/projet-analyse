﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace MeetingScheduler
{
    public partial class MainWindow : Window
    {
        private readonly Dictionary<DateTime, List<string>> _employeeAvailability = new Dictionary<DateTime, List<string>>()
        {
            { new DateTime(2024, 3, 10), new List<string> { "Alice", "Bob" } },
            { new DateTime(2024, 3, 11), new List<string> { "Charlie", "Dave" } }
        };

        public MainWindow()
        {
            
        }

        private void CheckAvailability_Click(object sender, RoutedEventArgs e, object meetingDate)
        {
            DateTime? selectedDate = meetingDate.SelectedDate;
            if (!selectedDate.HasValue)
            {
                MessageBox.Show("Please select a valid date.");
                return;
            }

            TimeSpan selectedTime;
            if (!TimeSpan.TryParse(meetingTime.Text, out selectedTime))
            {
                MessageBox.Show("Please enter a valid time.");
                return;
            }

            DisplayMeetingDetails(selectedDate.Value, selectedTime);
            UpdateEmployeeAvailability(selectedDate.Value);
        }

        private void DisplayMeetingDetails(DateTime selectedDate, TimeSpan selectedTime)
        {
            detailsTitle.Text = $"Title: {meetingTitle.Text}";
            detailsDate.Text = $"Date: {selectedDate:yyyy-MM-dd}";
            detailsTime.Text = $"Time: {selectedTime}";
        }

        private void UpdateEmployeeAvailability(DateTime selectedDate)
        {
            availableEmployees.Items.Clear(); // Clear previous entries

            List<string> employees;
            if (_employeeAvailability.TryGetValue(selectedDate, out employees))
            {
                foreach (var employee in employees)
                {
                    availableEmployees.Items.Add(employee);
                }
            }
            else
            {
                availableEmployees.Items.Add("No employees available");
            }
        }

        private void availableEmployees_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            selectedEmployees.Items.Clear(); // Clear previous selections
            foreach (var item in availableEmployees.SelectedItems)
            {
                selectedEmployees.Items.Add(item);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
          
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // Logic to open the Schedule Meeting window
            var scheduleMeetingWindow = new MeetingScheduler.MainWindow();
            scheduleMeetingWindow.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            // Logic to open the Add Employee window
            var addEmployeeWindow = new ScheduleApp.MainWindow();
            addEmployeeWindow.Show();
        }
    }
}
