﻿namespace MeetingScheduler
{
    internal class meetingTitle
    {
        public static object Text { get; internal set; }
    }
}