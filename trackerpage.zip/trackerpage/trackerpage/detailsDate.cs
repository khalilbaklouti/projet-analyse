﻿namespace MeetingScheduler
{
    internal class detailsDate
    {
        internal static string Text;
    }
}